package com.gamingroom;

public class Entity {
	private long id;
	private String name; //like the properties for team player and game
	
	public Entity() {} //default constructor
	
	public Entity(long id, String name) {
		this.id = id;
		this.name = name;
	}
	//constructor with properties
	
	public long getId() {
		return id;
	}
	//getters for the properties
	public String getName() {
		return name;
	}
	
	@Override
	public String toString() {
		return "Entity [id=" + id + ", name=" + name + "]";
	}
}
