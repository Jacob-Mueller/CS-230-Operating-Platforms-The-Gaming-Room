package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team extends Entity {
	long id;
	String name;
	
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		this.id = id;
		this.name = name;
	}

	/*
	 @return the id
	 */
	public long getId() {
		return id;
	}

	/*
	 @return the name
	 */
	public String getName() {
		return name;
	}

	//add player block, new list and iterator
	private static List<Player> players = new ArrayList<Player>();

	public Player addPlayer(String name) {

		// a local game instance
		Player player = null;

		// FIXM: Use iterator to look for existing game with same name
		// if found, simply return the existing instance
		Iterator<Player> playersIterator = players.iterator(); //instance iterator
		
		do {
			Player playerInstance = playersIterator.next();
			
			if(playerInstance.getName() == name) {
				return playerInstance;
			}
		}while(playersIterator.hasNext());
		//do while loop for when a game is being added.

		// if not found, make a new game instance and add to list of games
		if (player == null) {
			players.add(player);
		}

		// return the new/existing game instance to the caller
		return player;
	}

	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + "]";
	}
}
